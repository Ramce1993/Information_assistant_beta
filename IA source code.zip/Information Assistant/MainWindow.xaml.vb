﻿Imports System.IO
Imports System.Windows.Media.Media3D
Imports System.Xml
Imports System.Windows.Media
Imports System.Windows.Forms
Imports System.Net
Imports System.Speech

Class MainWindow

    Public Function IsInternetConnected() As Boolean
        Try
            Using client = New WebClient()
                Using stream = client.OpenRead("http://www.google.com")
                    Return True
                End Using
            End Using
        Catch
        End Try
        Return False
    End Function

    Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs)

        usern.Content = Environment.UserName

        'color settings
        Try
            My.Settings.Reload()
        Catch

            My.Settings.mecolor = "#19A2DE"

            Dim bluecolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)

            usern.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)

            good.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)

            sectionofday.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)

            MAAND.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)

            dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)

            dag.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
            cmndline.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
            tijd.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
            cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(bluecolor)
            Me.BorderBrush = New System.Windows.Media.SolidColorBrush(bluecolor)
            cmndline.BorderBrush = New System.Windows.Media.SolidColorBrush(bluecolor)
            batt.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
        End Try

        Me.MinHeight = 600
        Me.MinWidth = 450

        Dim NotifyTimer = New System.Windows.Threading.DispatcherTimer()
        AddHandler NotifyTimer.Tick, AddressOf NotifyTimer_Tick
        NotifyTimer.Interval = New TimeSpan(0, 0, 1)
        NotifyTimer.Start()

        If tijd.Content > "00: 00" Then
            sectionofday.Content = "morning"
        End If
        If tijd.Content > "06:00" Then
            sectionofday.Content = "morning"
        End If
        If tijd.Content > "12:00" Then
            sectionofday.Content = "afternoon"
        End If
        If tijd.Content > "17:00" Then
            sectionofday.Content = "evening"
        End If
        If tijd.Content > "22:00" Then
            sectionofday.Content = "night"
        End If

        mibattery()

        cmndline.Focus()

    End Sub

    Private Sub NotifyTimer_Tick(sender As Object, e As EventArgs)

        tijd.Content = System.DateTime.Now.ToShortTimeString()
        dag.Content = System.DateTime.Now.Day
        dagvdweek.Content = System.DateTime.Now.DayOfWeek
        cmndline.BorderThickness = New Thickness("0")

        'applications

        If My.Settings.METROSTATE = "mini" Then
            ministate()
        Else
            deskstate()
        End If

        If My.Settings.backcolor = "black" Then
            If My.Settings.transparant = "false" Then
                metransparantblackhex()
            Else
                metransparantblackthex()
            End If

        Else
            If My.Settings.transparant = "false" Then
                metransparantwhitehex()
            Else
                metransparantwhitethex()
            End If
        End If

        Try
            Dim mycolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)

            MAAND.Foreground = New System.Windows.Media.SolidColorBrush(mycolor)

            dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(mycolor)

            dag.Foreground = New System.Windows.Media.SolidColorBrush(mycolor)

            cmndline.Foreground = New System.Windows.Media.SolidColorBrush(mycolor)
            tijd.Foreground = New System.Windows.Media.SolidColorBrush(mycolor)
            cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(mycolor)
            Me.BorderBrush = New System.Windows.Media.SolidColorBrush(mycolor)
            cmndline.BorderBrush = New System.Windows.Media.SolidColorBrush(mycolor)
            usern.Foreground = New System.Windows.Media.SolidColorBrush(mycolor)

            good.Foreground = New System.Windows.Media.SolidColorBrush(mycolor)

            sectionofday.Foreground = New System.Windows.Media.SolidColorBrush(mycolor)

            batt.Foreground = New System.Windows.Media.SolidColorBrush(mycolor)
        Catch
        End Try

        If tijd.Content > "00:00" Then
            sectionofday.Content = "morning"
        End If
        If tijd.Content > "06:00" Then
            sectionofday.Content = "morning"
        End If
        If tijd.Content > "12:00" Then
            sectionofday.Content = "afternoon"
        End If
        If tijd.Content > "17:00" Then
            sectionofday.Content = "evening"
        End If
        If tijd.Content > "22:00" Then
            sectionofday.Content = "night"
        End If

        If System.DateTime.Now.Month = 1 Then
            MAAND.Content = "january"

        End If
        If System.DateTime.Now.Month = 2 Then
            MAAND.Content = "februari"

        End If
        If System.DateTime.Now.Month = 3 Then
            MAAND.Content = "march"

        End If
        If System.DateTime.Now.Month = 4 Then
            MAAND.Content = "april"

        End If
        If System.DateTime.Now.Month = 5 Then
            MAAND.Content = "mei"

        End If
        If System.DateTime.Now.Month = 6 Then
            MAAND.Content = "june"

        End If
        If System.DateTime.Now.Month = 7 Then
            MAAND.Content = "juli"

        End If
        If System.DateTime.Now.Month = 8 Then
            MAAND.Content = "august"

        End If
        If System.DateTime.Now.Month = 9 Then
            MAAND.Content = "september"

        End If
        If System.DateTime.Now.Month = 10 Then
            MAAND.Content = "october"

        End If
        If System.DateTime.Now.Month = 11 Then
            MAAND.Content = "november"

        End If
        If System.DateTime.Now.Month = 12 Then

            'allow interuption

            MAAND.Content = "december"

        End If



        mibattery()

    End Sub

    Private Sub mibattery()

        Dim status As PowerStatus = SystemInformation.PowerStatus
        Dim percent As Single = status.BatteryLifePercent
        Dim percent_text As String = percent.ToString("P0")

        If status.PowerLineStatus = PowerLineStatus.Online Then

            If percent < 1.0F Then
                My.Settings.battery = percent_text
                batt.Opacity = "100"
            Else
                batt.Opacity = "0"
            End If
        Else
            My.Settings.battery = percent_text
            batt.Opacity = "100"
        End If

        My.Settings.battery = percent


        'txtChargeStatus.Text = status.BatteryChargeStatus.ToString()
        'txtFullLifetime.Text = If(status.BatteryFullLifetime = -1, "Unknown", status.BatteryFullLifetime.ToString())
        ' My.Settings.battery = status.BatteryLifePercent.ToString("P0")
        'txtLifeRemaining.Text = If(status.BatteryLifeRemaining = -1, "Unknown", status.BatteryLifeRemaining.ToString())
        'txtPowerLineStatus.Text = status.PowerLineStatus.ToString()
        batt.ToolTip = My.Settings.battery * 100
        batt.Value = My.Settings.battery
    End Sub

    Private Sub Window_KeyUp(sender As Object, e As Input.KeyEventArgs)


        If cmndline.Text = "" Then
            acon.Children.Clear()
            acon.Opacity = 0
        End If

        If cmndline.Text = "<ia>" Then
            Try
                Dim dirai As System.IO.DirectoryInfo = New System.IO.DirectoryInfo("c:/ia")
                Dim countai As Integer = dirai.GetFiles().Length
            Catch
            End Try

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.StartsWith("c:") Then

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.StartsWith("d:") Then

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.StartsWith("e:") Then

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.StartsWith("f:") Then

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.StartsWith("g:") Then

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.StartsWith("C:") Then

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.StartsWith("D:") Then

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.StartsWith("E:") Then

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.StartsWith("F:") Then

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.StartsWith("G:") Then

            acon.Opacity = 100
            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)

        End If

        If cmndline.Text.Contains("me.social") Then

            acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim mysocial As New mesocial
            mysocial.Height = 120
            mysocial.Width = 120
            mysocial.HorizontalAlignment = HorizontalAlignment.Center
            mysocial.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(mysocial)
            mysocial.Focus()
        End If

        If cmndline.Text.Contains("explorer") Then

            acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.Contains("onedrive") Then

            acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim ondrv As New onedrive
            ondrv.Height = 120
            ondrv.Width = 120
            ondrv.HorizontalAlignment = HorizontalAlignment.Center
            ondrv.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(ondrv)
        End If

        If cmndline.Text.Contains("documents") Then
            Dim dirdoc As System.IO.DirectoryInfo = New System.IO.DirectoryInfo("c:/users/" & Environment.UserName & "/documents")
            Dim countdoc As Integer = dirdoc.GetFiles().Length

            acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text = "downloads" Then
            Dim dirdown As System.IO.DirectoryInfo = New System.IO.DirectoryInfo("c:/users/" & Environment.UserName & "/downloads")
            Dim countdown As Integer = dirdown.GetFiles().Length

            acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.Contains("pictures") Then
            Dim dir As System.IO.DirectoryInfo = New System.IO.DirectoryInfo("c:/users/" & Environment.UserName & "/pictures")
            Dim count As Integer = dir.GetFiles().Length

            acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.Contains("music") Then
            Dim dirmus As System.IO.DirectoryInfo = New System.IO.DirectoryInfo("c:/users/" & Environment.UserName & "/music")
            Dim countmus As Integer = dirmus.GetFiles().Length

            acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text.Contains("video") Then
            Dim dirvid As System.IO.DirectoryInfo = New System.IO.DirectoryInfo("c:/users/" & Environment.UserName & "/videos")
            Dim countvid As Integer = dirvid.GetFiles().Length

            acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim explor As New xplorer
            explor.Height = 120
            explor.Width = 120
            explor.HorizontalAlignment = HorizontalAlignment.Center
            explor.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(explor)
        End If

        If cmndline.Text = "photoshop" Then

            acon.Opacity = 100

            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim psicon As New photocon
            psicon.Height = 120
            psicon.Width = 120
            psicon.HorizontalAlignment = HorizontalAlignment.Center
            psicon.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(psicon)
        End If

        If cmndline.Text = "youtube" Then

            acon.Opacity = 100
            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim yticon As New youtubeicon
            yticon.Height = 120
            yticon.Width = 120
            yticon.HorizontalAlignment = HorizontalAlignment.Center
            yticon.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(yticon)
        End If

        If cmndline.Text = "settings" Then
            acon.Opacity = 100
            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim settss As New settingsx
            settss.Height = 120
            settss.Width = 120
            settss.HorizontalAlignment = HorizontalAlignment.Center
            settss.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(settss)

        End If

        If cmndline.Text.StartsWith("06") Then

            acon.Opacity = 100
            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim callcon As New callcontrol
            callcon.Height = 120
            callcon.Width = 120
            callcon.HorizontalAlignment = HorizontalAlignment.Center
            callcon.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(callcon)
        End If

        If cmndline.Text = "inbox" Then

            acon.Opacity = 100

            acon.Children.Clear()

            acon.Height = 120
            acon.Width = 120
            Dim mailinbox As New mail
            mailinbox.Height = 120
            mailinbox.Width = 120
            mailinbox.HorizontalAlignment = HorizontalAlignment.Center
            mailinbox.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(mailinbox)
        End If

        'mail subcommands
        If cmndline.Text.Contains("@") Then
            If cmndline.Text.Contains(".com") Then

                acon.Opacity = 100
                acon.Children.Clear()
                acon.Height = 120
                acon.Width = 120
                Dim mailinbox As New mail
                mailinbox.Height = 120
                mailinbox.Width = 120
                mailinbox.HorizontalAlignment = HorizontalAlignment.Center
                mailinbox.VerticalAlignment = VerticalAlignment.Center
                acon.Children.Add(mailinbox)
            End If
        End If

        If cmndline.Text.Contains("@") Then
            If cmndline.Text.Contains(".nl") Then

                acon.Opacity = 100
                acon.Children.Clear()
                acon.Height = 120
                acon.Width = 120
                Dim mailinbox As New mail
                mailinbox.Height = 120
                mailinbox.Width = 120
                mailinbox.HorizontalAlignment = HorizontalAlignment.Center
                mailinbox.VerticalAlignment = VerticalAlignment.Center
                acon.Children.Add(mailinbox)
            End If
        End If

        If cmndline.Text = "calendar" Then

                acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim calendarss As New calendarcontrol
            calendarss.Height = 120
            calendarss.Width = 120
            calendarss.HorizontalAlignment = HorizontalAlignment.Center
            calendarss.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(calendarss)
        End If

            If cmndline.Text = "spotify" Then

                acon.Opacity = 100
                acon.Children.Clear()
                acon.Height = 120
                acon.Width = 120
                Dim aconspot As New aconspotify
                aconspot.Height = 120
                aconspot.Width = 120
                aconspot.HorizontalAlignment = HorizontalAlignment.Center
                aconspot.VerticalAlignment = VerticalAlignment.Center
                acon.Children.Add(aconspot)
            End If

            If cmndline.Text.StartsWith("www.") Then

                acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim iexplorr As New internetcontrol
            iexplorr.Height = 120
            iexplorr.Width = 120
            iexplorr.HorizontalAlignment = HorizontalAlignment.Center
            iexplorr.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(iexplorr)
        End If

            If cmndline.Text = "internet" Then

                acon.Opacity = 100
                acon.Children.Clear()
                acon.Height = 120
                acon.Width = 120
                Dim iexplorr As New internetcontrol
                iexplorr.Height = 120
                iexplorr.Width = 120
                iexplorr.HorizontalAlignment = HorizontalAlignment.Center
                iexplorr.VerticalAlignment = VerticalAlignment.Center
                acon.Children.Add(iexplorr)
            End If

            If cmndline.Text = "office" Then

                acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim myoffice As New office
            myoffice.Height = 120
            myoffice.Width = 120
            myoffice.HorizontalAlignment = HorizontalAlignment.Center
            myoffice.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(myoffice)

        End If

        If cmndline.Text.Contains("wikipedia") Then

                acon.Opacity = 100
            acon.Children.Clear()
            acon.Height = 120
            acon.Width = 120
            Dim wkpedia As New wkipedia
            wkpedia.Height = 120
            wkpedia.Width = 120
            wkpedia.HorizontalAlignment = HorizontalAlignment.Center
            wkpedia.VerticalAlignment = VerticalAlignment.Center
            acon.Children.Add(wkpedia)
        End If

            If cmndline.Text.Contains("twitter") Then

                acon.Opacity = 100
                acon.Children.Clear()
                acon.Height = 120
                acon.Width = 120
                Dim twetcon As New twitteracon
                twetcon.Height = 120
                twetcon.Width = 120
                twetcon.HorizontalAlignment = HorizontalAlignment.Center
                twetcon.VerticalAlignment = VerticalAlignment.Center
                acon.Children.Add(twetcon)
            End If


            If cmndline.Text = "me.valuta" Then

                acon.Opacity = 100
                acon.Children.Clear()
                acon.Height = 120
                acon.Width = 120
                Dim currcon As New valutacon
                currcon.Height = 120
                currcon.Width = 120
                currcon.HorizontalAlignment = HorizontalAlignment.Center
                currcon.VerticalAlignment = VerticalAlignment.Center
                acon.Children.Add(currcon)
            End If
        '--------------------------------------------------------------------------------- Key.enter

        If e.Key = Key.Enter Then

            Try

                Dim file As String
                file = "c:\ia\" & cmndline.Text & ".txt"

                If My.Computer.FileSystem.FileExists(file) Then


                    Dim line As String
                    ' Create new StreamReader instance with Using block.
                    Using reader As StreamReader = New StreamReader(file)
                        ' Read one line from file
                        line = reader.ReadLine
                    End Using
                    Try
                        Process.Start(line)
                    Catch

                    End Try
                End If
            Catch
                Try

                    Dim fil2e As String
                    fil2e = "c:\ia\" & cmndline.Text & ".exe"

                    If My.Computer.FileSystem.FileExists(fil2e) Then


                        Dim lin2e As String
                        ' Create new StreamReader instance with Using block.
                        Using reader As StreamReader = New StreamReader(fil2e)
                            ' Read one line from file
                            lin2e = reader.ReadLine
                        End Using
                        Try
                            Process.Start(lin2e)
                        Catch

                        End Try
                    End If
                Catch

                End Try
            End Try

            If cmndline.Text = "<ia>" Then
                Try
                    Process.Start("C:\ia")
                Catch
                End Try

            End If

            If cmndline.Text = "photoshop" Then
                Try
                    Dim locationphotoshop As String
                    locationphotoshop = "C:\ia\applications\PhotoshopPortable\" & cmndline.Text & ".exe"
                    Process.Start(locationphotoshop)
                Catch

                End Try
            End If

            If cmndline.Text.StartsWith("o-") Then
                Process.Start("https://www.bing.com/search?q=" & cmndline.Text)
            End If


            If cmndline.Text = "me.online" Then
                My.Settings.Me_social_status = "online"
            End If

            If cmndline.Text = "me.offline" Then
                My.Settings.Me_social_status = "offline"
            End If

            'people

            ' If cmndline.Text = "add contact" Then
            ''     Dim adresses As New Adress_book
            'adresses.Show()
            'End If

            '  If cmndline.Text = "add favorite" Then
            ' Dim adresses As New Adress_book
            ' adresses.Show()
            'End If

            'If cmndline.Text = "add friend" Then
            ' Dim adresses As New Adress_book
            '     adresses.Show()
            'End If

            '  If cmndline.Text = "adress book" Then
            ' Dim adresses As New Adress_book
            ' adresses.Show()
            'End If

            'politiek

            If cmndline.Text = "mcdelivery" Then
                Process.Start("https://mcdelivery.mcdonalds.nl/")
            End If

            If cmndline.Text = "twitter/explore" Then
                Process.Start("https://twitter.com/explore")
            End If

            If cmndline.Text = "facebook/watch" Then
                Process.Start("https://www.facebook.com/watch/?ref=tab")
            End If

            If cmndline.Text = "facebook/feed" Then
                Process.Start("https://www.facebook.com/groups/feed/")
            End If

            If cmndline.Text = "facebook/gaming" Then
                Process.Start("https://www.facebook.com/gaming/feed/")
            End If

            If cmndline.Text = "facebook/messenger" Then
                Process.Start("https://www.facebook.com/messages/t/100000076338019/")
            End If

            If cmndline.Text = "facebook/friends" Then
                Process.Start("https://www.facebook.com/friends")
            End If


            If cmndline.Text.StartsWith("vscode.dev/") Then
                Process.Start("https://" + cmndline.Text)
            End If

            If cmndline.Text = "vscode.dev" Then
                Process.Start("https://vscode.dev/")
            End If

            If cmndline.Text.StartsWith("desktop") Then

                Try
                    Process.Start("C:\Users\" & Environment.UserName & "\" & cmndline.Text)
                Catch

                End Try

            End If

            If cmndline.Text = "me.desk" Then
                My.Settings.METROSTATE = "desk"
                deskstate()
            End If

            If cmndline.Text = "me.mini" Then
                My.Settings.METROSTATE = "mini"
                ministate()
            End If

            If cmndline.Text = "me.black" Then
                Me.Background = Brushes.Black
                My.Settings.backcolor = "black"
                If My.Settings.transparant = "false" Then
                    metransparantblackhex()
                Else
                    metransparantblackthex()
                End If
            End If

            If cmndline.Text = "me.white" Then
                Me.Background = Brushes.White
                My.Settings.backcolor = "white"
                If My.Settings.transparant = "false" Then
                    metransparantwhitehex()
                Else
                    metransparantwhitethex()
                End If
            End If

            'HIER IS DIE RAMADAN!


            If cmndline.Text = "me.solid" Then
                My.Settings.transparant = "false"
            End If

            If cmndline.Text = "me.glass" Then
                My.Settings.transparant = "true"
            End If
            If cmndline.Text = "blue" Then
                My.Settings.mecolor = "#19A2DE"
                Dim bluecolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(bluecolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(bluecolor)
                cmndline.BorderBrush = New System.Windows.Media.SolidColorBrush(bluecolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)

            End If

            If cmndline.Text = "gold" Then
                My.Settings.mecolor = "#FFFFD700"

                Dim goldcolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(goldcolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(goldcolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(goldcolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(goldcolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(goldcolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(goldcolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(goldcolor)
                cmndline.BorderBrush = New System.Windows.Media.SolidColorBrush(goldcolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(goldcolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(goldcolor)

            End If

            If cmndline.Text = "red" Then
                My.Settings.mecolor = "#FFE61400"

                Dim redcolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(redcolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(redcolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(redcolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(redcolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(redcolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(redcolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(redcolor)
                cmndline.BorderBrush = New System.Windows.Media.SolidColorBrush(redcolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(redcolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(redcolor)

            End If

            If cmndline.Text = "brown" Then

                My.Settings.mecolor = "#FFA52A2A"
                Dim browncolor As Color = CType(ColorConverter.ConvertFromString("#FFA52A2A"), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(browncolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(browncolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(browncolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(browncolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(browncolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(browncolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(browncolor)
                cmndline.BorderBrush = New System.Windows.Media.SolidColorBrush(browncolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(browncolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(browncolor)

            End If

            If cmndline.Text = "green" Then

                My.Settings.mecolor = "#FF008000"
                Dim greencolor As Color = CType(ColorConverter.ConvertFromString("#FF008000"), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(greencolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(greencolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(greencolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(greencolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(greencolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(greencolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(greencolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(greencolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(greencolor)

            End If

            If cmndline.Text = "pink" Then

                My.Settings.mecolor = "#FFFF69B4"
                Dim pinkcolor As Color = CType(ColorConverter.ConvertFromString("#FFFF69B4"), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(pinkcolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(pinkcolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(pinkcolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(pinkcolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(pinkcolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(pinkcolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(pinkcolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(pinkcolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(pinkcolor)


            End If

            If cmndline.Text = "purple" Then

                My.Settings.mecolor = "#FF800080"
                Dim purplecolor As Color = CType(ColorConverter.ConvertFromString("#FF800080"), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(purplecolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(purplecolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)

            End If

            If cmndline.Text = "lime" Then

                My.Settings.mecolor = "#FF00FF00"
                Dim limecolor As Color = CType(ColorConverter.ConvertFromString("#FF00FF00"), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(limecolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(limecolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(limecolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(limecolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(limecolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(limecolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(limecolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(limecolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(limecolor)
            End If

            If cmndline.Text = "aqua" Then

                My.Settings.mecolor = "#FF00FFFF"
                Dim aquacolor As Color = CType(ColorConverter.ConvertFromString("#FF00FFFF"), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(aquacolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(aquacolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(aquacolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(aquacolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(aquacolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(aquacolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(aquacolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(aquacolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(aquacolor)

            End If

            If cmndline.Text = "steel" Then

                My.Settings.mecolor = "#FF4682B4"
                Dim steelcolor As Color = CType(ColorConverter.ConvertFromString("#FF4682B4"), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(steelcolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(steelcolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(steelcolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(steelcolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(steelcolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(steelcolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(steelcolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(steelcolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(steelcolor)
            End If
            If cmndline.Text = "orange" Then

                My.Settings.mecolor = "#FFFFA500"
                Dim purplecolor As Color = CType(ColorConverter.ConvertFromString("#FFFFA500"), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(purplecolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(purplecolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(purplecolor)
            End If
            If cmndline.Text = "yellow" Then


                My.Settings.mecolor = "#FFFFFF00"
                Dim yellowcolor As Color = CType(ColorConverter.ConvertFromString("#FFFFA500"), Color)
                MAAND.Foreground = New System.Windows.Media.SolidColorBrush(yellowcolor)
                dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(yellowcolor)
                dag.Foreground = New System.Windows.Media.SolidColorBrush(yellowcolor)
                cmndline.Foreground = New System.Windows.Media.SolidColorBrush(yellowcolor)
                tijd.Foreground = New System.Windows.Media.SolidColorBrush(yellowcolor)
                cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(yellowcolor)
                Me.BorderBrush = New System.Windows.Media.SolidColorBrush(yellowcolor)
                usern.Foreground = New System.Windows.Media.SolidColorBrush(yellowcolor)
                batt.Foreground = New System.Windows.Media.SolidColorBrush(yellowcolor)
            End If

            If cmndline.Text.StartsWith("#") Then
                'check if color is inserted.


                Try
                    My.Settings.mecolor = cmndline.Text
                    Dim bluecolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
                    MAAND.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                    dagvdweek.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                    dag.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                    cmndline.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                    tijd.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                    cmndline.SelectionBrush = New System.Windows.Media.SolidColorBrush(bluecolor)
                    Me.BorderBrush = New System.Windows.Media.SolidColorBrush(bluecolor)
                    cmndline.BorderBrush = New System.Windows.Media.SolidColorBrush(bluecolor)
                    usern.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                    batt.Foreground = New System.Windows.Media.SolidColorBrush(bluecolor)
                Catch
                End Try



                'check if needed to open tread application.

            End If

            If cmndline.Text = "feedback" Then
                Process.Start("mailto:ramcee@live.nl")
            End If

            If cmndline.Text = "me.close" Then
                Me.Close()
            End If


            'skype collection
            If cmndline.Text.StartsWith("06") Then
                Process.Start("skype:" & cmndline.Text)
            End If



            If cmndline.Text = "mail" Then
                Process.Start("https://outlook.live.com/mail/0/inbox")

            End If

            If cmndline.Text = "inbox" Then
                Process.Start("https://outlook.live.com/mail/0/inbox")

            End If


            If cmndline.Text = "favs" Then
                Process.Start("C:\Users\" & System.Environment.UserName & "\Favorites")
            End If

            If cmndline.Text.Contains(" - ") Then
                Process.Start("https://www.youtube.com/results?search_query=" + cmndline.Text)
            End If

            'mail

            'Browser


            If cmndline.Text.Contains(".tk") Then
                If cmndline.Text.StartsWith("www.") Then
                    Try
                        Process.Start(cmndline.Text)

                    Catch
                        'nothing

                    End Try


                Else
                    If cmndline.Text.StartsWith("http://") Then
                        Try
                            Process.Start(cmndline.Text)
                        Catch
                            'nothing
                        End Try
                    Else

                        If cmndline.Text.Contains("@") Then

                            Try

                                Process.Start("mailto:" & cmndline.Text)

                            Catch ex As Exception

                            End Try
                        Else
                            Process.Start("http://www." & cmndline.Text)

                        End If


                    End If



                End If
            End If
            If cmndline.Text.Contains(".space") Then
                If cmndline.Text.StartsWith("www.") Then
                    Try
                        Process.Start(cmndline.Text)

                    Catch
                        'nothing

                    End Try


                Else
                    If cmndline.Text.StartsWith("https://") Then
                        Try
                            Process.Start(cmndline.Text)
                        Catch
                            'nothing
                        End Try
                    Else

                        If cmndline.Text.Contains("@") Then

                            Try

                                Process.Start("mailto:" & cmndline.Text)

                            Catch ex As Exception

                            End Try
                        Else
                            Process.Start("http://www." & cmndline.Text)

                        End If


                    End If



                End If
            End If
            If cmndline.Text.Contains(".nl") Then
                If cmndline.Text.StartsWith("www.") Then
                    Try
                        Process.Start(cmndline.Text)

                    Catch
                        'nothing

                    End Try


                Else
                    If cmndline.Text.StartsWith("http://") Then
                        Try
                            Process.Start(cmndline.Text)
                        Catch
                            'nothing
                        End Try
                    Else

                        If cmndline.Text.Contains("@") Then

                            Try

                                Process.Start("mailto:" & cmndline.Text)

                            Catch ex As Exception

                            End Try
                        Else
                            Process.Start("http://" & cmndline.Text)

                        End If


                    End If



                End If
            End If
            If cmndline.Text.Contains(".io") Then
                If cmndline.Text.StartsWith("www.") Then
                    Try
                        Process.Start(cmndline.Text)

                    Catch
                        'nothing

                    End Try


                Else
                    If cmndline.Text.StartsWith("http://") Then
                        Try
                            Process.Start(cmndline.Text)
                        Catch
                            'nothing
                        End Try
                    Else

                        If cmndline.Text.Contains("@") Then

                            Try

                                Process.Start("mailto:" & cmndline.Text)

                            Catch ex As Exception

                            End Try
                        Else
                            Process.Start("http://" & cmndline.Text)

                        End If


                    End If



                End If
            End If
            If cmndline.Text.Contains(".com") Then
                If cmndline.Text.StartsWith("www.") Then
                    Try
                        Process.Start(cmndline.Text)

                    Catch
                        'nothing

                    End Try


                Else
                    If cmndline.Text.StartsWith("http://") Then
                        Try
                            Process.Start(cmndline.Text)
                        Catch
                            'nothing
                        End Try
                    Else

                        If cmndline.Text.Contains("@") Then

                            Try

                                Process.Start("mailto:" & cmndline.Text)

                            Catch ex As Exception

                            End Try
                        Else
                            Process.Start("http://www." & cmndline.Text)

                        End If


                    End If



                End If
            End If
            If cmndline.Text.Contains(".org") Then
                If cmndline.Text.StartsWith("www.") Then
                    Try
                        Process.Start(cmndline.Text)

                    Catch
                        'nothing

                    End Try


                Else
                    If cmndline.Text.StartsWith("http://") Then
                        Try
                            Process.Start(cmndline.Text)
                        Catch
                            'nothing
                        End Try
                    Else
                        If cmndline.Text.Contains("@") Then
                            Try
                                Process.Start("mailto:" & cmndline.Text)
                            Catch ex As Exception
                            End Try
                        Else
                            Process.Start("http://www." & cmndline.Text)
                        End If
                    End If
                End If
            End If
            If cmndline.Text.Contains(".net") Then
                If cmndline.Text.StartsWith("www.") Then
                    Try
                        Process.Start(cmndline.Text)

                    Catch
                        'nothing

                    End Try


                Else
                    If cmndline.Text.StartsWith("http://") Then
                        Try
                            Process.Start(cmndline.Text)
                        Catch
                            'nothing
                        End Try
                    Else

                        If cmndline.Text.Contains("@") Then

                            Try

                                Process.Start("mailto:" & cmndline.Text)

                            Catch ex As Exception

                            End Try
                        Else
                            Process.Start("http://www." & cmndline.Text)

                        End If


                    End If



                End If
            End If

            'explorer
            If cmndline.Text.StartsWith("<ia>me.social") Then
                Try
                    Process.Start("c:/ia/me/social")
                Catch
                    'nothing
                End Try
            End If


            If cmndline.Text.StartsWith("c:") Then
                Try
                    Process.Start(cmndline.Text)
                Catch
                    'nothing
                End Try
            End If
            If cmndline.Text.StartsWith("d:") Then
                Try
                    Process.Start(cmndline.Text)
                Catch
                    'nothing
                End Try
            End If
            If cmndline.Text.StartsWith("e:") Then
                Try
                    Process.Start(cmndline.Text)
                Catch
                    'nothing
                End Try
            End If
            If cmndline.Text.StartsWith("f:") Then
                Try
                    Process.Start(cmndline.Text)
                Catch
                    'nothing
                End Try
            End If
            If cmndline.Text.StartsWith("g:") Then
                Try
                    Process.Start(cmndline.Text)
                Catch
                    'nothing
                End Try


            End If
            If cmndline.Text.StartsWith("C:") Then
                Try
                    Process.Start(cmndline.Text)
                Catch
                    'nothing
                End Try
            End If
            If cmndline.Text.StartsWith("D:") Then
                Try
                    Process.Start(cmndline.Text)
                Catch
                    'nothing
                End Try
            End If
            If cmndline.Text.StartsWith("E:") Then
                Try
                    Process.Start(cmndline.Text)
                Catch
                    'nothing
                End Try
            End If
            If cmndline.Text.StartsWith("F:") Then
                Try
                    Process.Start(cmndline.Text)
                Catch
                    'nothing
                End Try
            End If
            If cmndline.Text.StartsWith("G:") Then
                Try
                    Process.Start(cmndline.Text)
                Catch
                    'nothing
                End Try


            End If

            If cmndline.Text = "documents" Then
                Process.Start("c:/users/" & Environment.UserName & "/documents")

            End If

            If cmndline.Text = "calculator" Then
                Process.Start("calculator://")

            End If

            If cmndline.Text = "pictures" Then
                Process.Start("c:/users/" & Environment.UserName & "/pictures")

            End If

            If cmndline.Text = "shutdown" Then
                Process.Start("shutdown", "/s /t 0")

            End If
            If cmndline.Text = "settings" Then
                Process.Start("MS-settings:")

            End If
            If cmndline.Text = "control panel" Then
                Process.Start("C:\Windows\System32\control.exe")

            End If

            If cmndline.Text = "network" Then
                Process.Start("MS-settings:network")

            End If

            If cmndline.Text = "wifi" Then
                Process.Start("ms-settings:network-wifi")

            End If

            If cmndline.Text = "about" Then
                Process.Start("ms-settings:about")

            End If

            If cmndline.Text = "accounts" Then
                Process.Start("ms-settings:accounts")

            End If

            If cmndline.Text = "bluetooth" Then
                Process.Start("ms-settings:bluetooth")

            End If

            If cmndline.Text = "devices" Then
                Process.Start("ms-settings:bluetooth & devices")

            End If

            If cmndline.Text = "system" Then
                Process.Start("ms-settings:bluetooth")

            End If

            If cmndline.Text = "program files" Then
                Process.Start("shell:ProgramFiles")

            End If
            If cmndline.Text = "3D objects" Then
                Process.Start("shell:3D Objects")

            End If
            If cmndline.Text = "..." Then
                Process.Start("shell:AppsFolder")

            End If

            'Internet


            If cmndline.Text = "internet" Then
                Process.Start("http://")
            End If


            'positioneer deze correct Ramadan!!
            If cmndline.Text = "powned" Then
                Process.Start("https://www.youtube.com/channel/UCHTtspK-G7Wt68awRpTSkiw")
            End If


            If cmndline.Text = "wikihow" Then
                Process.Start("https://www.wikihow.nl/")
            End If

            If cmndline.Text = "discord" Then
                Process.Start("https://discord.com/")

            End If

            If cmndline.Text = "earth" Then
                Process.Start("https://earth.google.com/web/")


            End If
            If cmndline.Text = "ikea" Then
                Process.Start("https://www.ikea.com/")

            End If

            If cmndline.Text = "burger king" Then
                Process.Start("https://www.burgerking.nl/")

            End If

            If cmndline.Text = "lidl" Then
                Process.Start("https://www.lidl.nl/")

            End If

            If cmndline.Text = "aliexpress" Then
                Process.Start("https://www.aliexpress.com/")

            End If

            If cmndline.Text = "wikipedia" Then
                Process.Start("https://www.wikipedia.com/")

            End If
            If cmndline.Text = "back-werk" Then
                Process.Start("https://www.back-werk.nl/")

            End If

            If cmndline.Text = "9292" Then
                Process.Start("http://www.9292.nl")

            End If
            If cmndline.Text = "9gag" Then
                Process.Start("https://www.9gag.com")
            End If

            '#A

            If cmndline.Text = "apple" Then
                Process.Start("www.apple.com")
            End If

            If cmndline.Text = "anwb" Then
                Process.Start("http://www.anwb.nl")

            End If

            '#B


            If cmndline.Text = "blokker" Then
                Process.Start("https://www.blokker.nl")

            End If

            If cmndline.Text = "bing" Then
                Process.Start("https://www.bing.com")

            End If

            If cmndline.Text = "blend" Then
                Try
                    Process.Start("C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\Common7\IDE\Blend.exe")
                Catch
                End Try

            End If

            ' If cmndline.Text = "blender" Then
            ' Process.Start("C:\Program Files\Blender Foundation\Blender 2.82\blender.exe")

            'End If

            '#C

            If cmndline.Text.StartsWith("c:/") Then
                If IO.Directory.Exists(cmndline.Text) Then

                    Process.Start(cmndline.Text)
                End If
            End If
            If cmndline.Text.StartsWith("c:\") Then
                If IO.Directory.Exists(cmndline.Text) Then
                    Process.Start(cmndline.Text)
                End If
            End If
            If cmndline.Text.Contains("C:/") Then
                If IO.Directory.Exists(cmndline.Text) Then

                    Process.Start(cmndline.Text)
                End If
            End If

            If cmndline.Text = "c:" Then
                If IO.Directory.Exists(cmndline.Text) Then
                    Process.Start(cmndline.Text)

                End If

            End If
            If cmndline.Text = "C:" Then

                If IO.Directory.Exists(cmndline.Text) Then
                    Process.Start(cmndline.Text)

                End If

            End If

            If cmndline.Text = "connections" Then
                Process.Start("shell:ConnectionsFolder")
            End If
            If cmndline.Text = "calendar" Then
                Process.Start("https://outlook.live.com/calendar/0/")
            End If

            '#D
            If cmndline.Text = "donate" Then
                Process.Start("https://www.doneeractie.nl/?c=1654831855&adg=66181170920&d=c&k=doneeractie&p=&gclid=Cj0KCQjwiNSLBhCPARIsAKNS4_c4outH72GfPcHuN59JSBOOK28ur_gSBuYosOfMW_rmRXpJvyhdlmcaAicOEALw_wcB")
            End If

            If cmndline.Text.Contains("d:/") Then
                If IO.Directory.Exists(cmndline.Text) Then
                    Process.Start(cmndline.Text)

                End If
            End If

            If cmndline.Text.Contains("D:/") Then
                If cmndline.Text.Contains("d:/") Then
                    If IO.Directory.Exists(cmndline.Text) Then
                        Process.Start(cmndline.Text)

                    End If
                End If
            End If

            If cmndline.Text = "d:" Then
                If IO.Directory.Exists(cmndline.Text) Then
                    Process.Start(cmndline.Text)

                End If

            End If
            If cmndline.Text = "D:" Then

                If IO.Directory.Exists(cmndline.Text) Then
                    Process.Start(cmndline.Text)

                End If

            End If
            'here ramadan
            If cmndline.Text = "display" Then
                Process.Start("ms-settings:display")

            End If

            If cmndline.Text = "Downloads" Then
                Process.Start("shell:Downloads")
            End If

            If cmndline.Text = "deviantart" Then
                Process.Start("http://www.deviantart.com")
            End If

            If cmndline.Text = "downloads" Then
                Process.Start("shell:Downloads")
            End If

            If cmndline.Text = "directions" Then
                Process.Start("https://www.bing.com/maps/directions")

            End If


            '#E
            If cmndline.Text.Contains("e:/") Then
                If IO.Directory.Exists(cmndline.Text) Then
                    Process.Start(cmndline.Text)

                End If
            End If


            If cmndline.Text.Contains("E:/") Then
                If cmndline.Text.Contains("d:/") Then
                    If IO.Directory.Exists(cmndline.Text) Then
                        Process.Start(cmndline.Text)

                    End If
                End If
            End If



            If cmndline.Text = "e:" Then
                If IO.Directory.Exists(cmndline.Text) Then
                    Process.Start(cmndline.Text)

                End If

            End If
            If cmndline.Text = "E:" Then

                If IO.Directory.Exists(cmndline.Text) Then
                    Process.Start(cmndline.Text)

                End If

            End If

            If cmndline.Text.StartsWith("e") Then
                If cmndline.Text = "excel" Then
                    Process.Start("https://office.live.com/start/Excel.aspx?auth=1")

                End If
                If cmndline.Text = "explorer" Then
                    Process.Start("explorer.exe")

                End If
                If cmndline.Text = "ebay" Then
                    Process.Start("https://www.ebay.com")

                End If
            End If

            '#F
            If cmndline.Text.StartsWith("f") Then

                If cmndline.Text = "favorites" Then
                    Process.Start("shell:Favorites")

                End If
                If cmndline.Text = "facebook" Then
                    Process.Start("https://www.facebook.com")

                End If
                If cmndline.Text = "fruity loops" Then
                    Try
                        Process.Start("C:\Program Files\Image-Line\FL Studio 20\FL64.exe")
                    Catch
                    End Try

                End If

            End If

            '#G

            If cmndline.Text = "github" Then
                Process.Start("https://www.github.com/")
            End If
            If cmndline.Text = "gamma" Then
                Process.Start("https://www.gamma.nl")
            End If
            If cmndline.Text = "google" Then
                Process.Start("https://www.google.nl")
            End If
            If cmndline.Text = "gmail" Then
                Process.Start("https://www.gmail.com")
            End If

            '#H

            '#I  

            If cmndline.Text = "ikea" Then
                Process.Start("https://www.ikea.com")
            End If
            If cmndline.Text = "instructables" Then
                Process.Start("https://www.instructables.com")
            End If
            If cmndline.Text = "instagram" Then
                Process.Start("https://www.instagram.com/")
            End If

            '#J


            If cmndline.Text = "jbl" Then
                Process.Start("https://www.jbl.com")

            End If

            '#L
            If cmndline.Text = "lock" Then
                Process.Start("rundll32.exe", "user32.dll,LockWorkStation")
            End If

            '#M
            If cmndline.Text = "me.minimize" Then
                Me.WindowState = WindowState.Minimized
            End If

            If cmndline.Text = "mcdonalds" Then
                Process.Start("https://www.mcdonalds.com")

            End If

            '#N

            If cmndline.Text = System.Environment.UserName Then
                Process.Start("C:\Users\" & System.Environment.UserName)
            End If


            '#o

            If cmndline.Text = "office" Then
                Process.Start("https://www.office.com/?auth=1")

            End If
            If cmndline.Text = "onedrive" Then
                Try
                    Process.Start("C:\Users\" & System.Environment.UserName & "\OneDrive\")

                Catch
                    Try
                        Process.Start(":onedrive")
                    Catch
                        Process.Start("http://www.onedrive.com")
                    End Try

                End Try


            End If

            If cmndline.Text = "outlook" Then
                Process.Start("https://outlook.live.com/mail/0/inbox")

            End If

            If cmndline.Text = "onenote" Then
                Process.Start("https://www.onenote.com/notebooks?ui=nl%2DNL&rs=NL&auth=1")

            End If

            '#P

            If cmndline.Text = "people" Then
                Process.Start("https://outlook.live.com/people/0/")
            End If
            If cmndline.Text = "photoshop" Then
                Try
                    Process.Start("D:\program files\PhotoshopPortable\PhotoshopCS6Portable.exe")
                Catch

                End Try
            End If
            If cmndline.Text = "#^MC=" Then
                Process.Start("https://rxmci.000webhostapp.com/")
            End If

            If cmndline.Text = "powerpoint" Then
                Process.Start("https://office.live.com/start/PowerPoint.aspx?auth=1")
            End If

            If cmndline.Text = "printers" Then
                Process.Start("shell:PrintersFolder")
            End If

            '#R

            If cmndline.Text = "reboot" Then
                Process.Start("shutdown", "/r /t 0")
            End If
            If cmndline.Text = "restart" Then
                Process.Start("shutdown", "/r /t 0")
            End If

            If cmndline.Text = "regedit" Then
                Process.Start("regedit.exe")
            End If

            '#S

            If cmndline.Text = "screenshots" Then
                Try
                    Process.Start("C:\Users\" & System.Environment.UserName & "\OneDrive\Pictures\Screenshots")
                Catch ex As Exception
                    'nothing
                End Try
            End If
            If cmndline.Text = "store" Then
                Process.Start("MS-store:")
            End If

            If cmndline.Text = "startup" Then
                Process.Start("shell:Startup")
            End If
            If cmndline.Text = "skype" Then
                Process.Start("skype:")
            End If
            '#T

            If cmndline.Text = "todo" Then
                Process.Start("https://to-do.live.com")
            End If

            If cmndline.Text = "twitter" Then
                Process.Start("http://www.twitter.com/")
            End If
            If cmndline.Text = "task manager" Then
                Process.Start("taskmgr.exe")
            End If


            If cmndline.Text = "teams" Then
                Process.Start("https://teams.live.com/_?utm_source=OfficeWeb")
            End If

            '#U

            If cmndline.Text = "unity" Then
                Process.Start("C:\Program Files\Unity\Editor\Unity.exe")
            End If

            '#V

            If cmndline.Text = "vscode.dev" Then
                Process.Start("https://vscode.dev/")
            End If

            If cmndline.Text = "videos" Then
                Process.Start("shell:My Video")
            End If
            If cmndline.Text = "weather" Then
                Process.Start("BingWeather:")
            End If
            If cmndline.Text = "wikipedia" Then
                Process.Start("https://www.wikipedia.org")
            End If
            If cmndline.Text = "wikihow" Then
                Process.Start("https://www.wikihow.com")
            End If

            If cmndline.Text = "word" Then
                Process.Start("https://office.live.com/start/Word.aspx?auth=1")
            End If

            '#Y
            If cmndline.Text = "youtube" Then
                Process.Start("https://www.youtube.com")
            End If
            If cmndline.Text = "Youtube" Then
                Process.Start("https://www.youtube.com")
            End If
            If cmndline.Text = "youtube/library" Then
                Process.Start("https://www.youtube.com/feed/library")
            End If

            If cmndline.Text = "y6" Then
                Process.Start("https://www.youtube.com/playlist?list=LLsHs_UtOlHIR9aqvrfRs4Pg")
            End If
            If cmndline.Text = "yuzu" Then
                Try
                    Process.Start("C:\Users\" & Environment.UserName & "\AppData\Local\yuzu\yuzu-windows-msvc/yuzu.exe")
                Catch

                End Try
            End If

            acon.Opacity = 0
            cmndline.Text = ""
            cmndline.Focus()
        End If
    End Sub

    Private Sub deskstate()
        Me.WindowState = WindowState.Maximized
        'load desk settings
        usern.VerticalAlignment = VerticalAlignment.Top
        usern.Margin = New Thickness(7, 34, 0, 0)
        batt.Margin = New Thickness(0, 0, 0, 6)
    End Sub

    Private Sub ministate()
        Me.WindowState = WindowState.Normal

        Me.WindowStartupLocation = WindowStartupLocation.CenterScreen
        Me.MinHeight = 600
        Me.MinWidth = 450

        usern.VerticalAlignment = VerticalAlignment.Top
        batt.Margin = New Thickness(0, 0, 0, 0)
        usern.Margin = New Thickness(7, 34, 0, 0)
    End Sub

    Private Sub Window_MouseLeftButtonDown(sender As Object, e As MouseButtonEventArgs)
        Try
            Me.DragMove()
        Catch
        End Try
    End Sub

    Private Sub cmndline_MouseLeftButtonDown(sender As Object, e As MouseButtonEventArgs) Handles cmndline.MouseLeftButtonDown
        'werk niet
        Process.Start("C:\Windows\System32\osk.exe")
    End Sub

    Private Sub dagvdweek_MouseDoubleClick(sender As Object, e As MouseButtonEventArgs) Handles dagvdweek.MouseDoubleClick
        Process.Start("https://outlook.live.com/calendar/0/view/week")
    End Sub

    Private Sub MAAND_MouseDoubleClick(sender As Object, e As MouseButtonEventArgs) Handles MAAND.MouseDoubleClick
        Process.Start("https://outlook.live.com/calendar/0/view/month")
    End Sub

    Private Sub dag_MouseDoubleClick(sender As Object, e As MouseButtonEventArgs) Handles dag.MouseDoubleClick
        Process.Start("https://outlook.live.com/calendar/0/view/day")
    End Sub

    Private Sub usern_MouseDoubleClick(sender As Object, e As MouseButtonEventArgs) Handles usern.MouseDoubleClick
        ' My.Settings.explorer_requestname = "myfolder"
        ' Dim ex As New explorer
        ' ex.Show()

        Process.Start("C:\Users\" & System.Environment.UserName)
    End Sub

    Private Sub Window_GotFocus(sender As Object, e As RoutedEventArgs)
        cmndline.Focus()
    End Sub

    Private Sub Label_MouseDoubleClick(sender As Object, e As MouseButtonEventArgs)
        Process.Start("ms-settings:network-wifi")
    End Sub

    Private Sub Label_MouseDoubleClick_1(sender As Object, e As MouseButtonEventArgs)
        Process.Start("ms-settings:bluetooth")
    End Sub

    Private Sub Window_LostFocus(sender As Object, e As RoutedEventArgs)
        Me.Topmost = False

    End Sub

    Private Sub metransparantwhitethex()
        Dim transparant As Color = CType(ColorConverter.ConvertFromString("#BFFFFFFF"), Color)

        Me.Background = New System.Windows.Media.SolidColorBrush(transparant)
    End Sub

    Private Sub metransparantblackthex()
        Dim transparant As Color = CType(ColorConverter.ConvertFromString("#BF000000"), Color)

        Me.Background = New System.Windows.Media.SolidColorBrush(transparant)
    End Sub

    Private Sub metransparantwhitehex()
        Me.Background = Brushes.White
    End Sub

    Private Sub metransparantblackhex()
        Me.Background = Brushes.Black
    End Sub

    Private Sub Window_Closing(sender As Object, e As System.ComponentModel.CancelEventArgs)
        My.Settings.Save()
    End Sub

    Private Sub Window_Drop(sender As Object, e As Windows.DragEventArgs)
        Try
            'disect string..
            Dim files() As String
            files = e.Data.GetData(DataFormats.FileDrop)

            My.Settings.droppedfull = files(0)

            My.Settings.dropped2fileextentionstripped = System.IO.Path.GetFileName(files(0))



            My.Settings.droppedfileextention = System.IO.Path.GetExtension(files(0))

            My.Settings.droppedfilename = System.IO.Path.GetFileNameWithoutExtension(files(0))
            cmndline.Text = My.Settings.droppedfilename

        Catch
        End Try
    End Sub
End Class
