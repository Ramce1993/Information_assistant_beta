﻿Public Class office
    Private Sub UserControl_Loaded(sender As Object, e As RoutedEventArgs)

    End Sub

    Private Sub UserControl_Loaded_1(sender As Object, e As RoutedEventArgs)
        Try
            Dim offccolors As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
            rectangleone.Stroke = New System.Windows.Media.SolidColorBrush(offccolors)
            rectangletwo.Stroke = New System.Windows.Media.SolidColorBrush(offccolors)
            rectangletree.Stroke = New System.Windows.Media.SolidColorBrush(offccolors)
            rectanglefour.Stroke = New System.Windows.Media.SolidColorBrush(offccolors)

        Catch

        End Try
    End Sub
End Class
