﻿Public Class callcontrol
    Private Sub UserControl_Loaded(sender As Object, e As RoutedEventArgs)
        Try
            Dim callnocolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
            xcall.Fill = New System.Windows.Media.SolidColorBrush(callnocolor)
        Catch

        End Try
    End Sub
End Class
