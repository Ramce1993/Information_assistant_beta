﻿Public Class xplorer
    Private Sub UserControl_Loaded(sender As Object, e As RoutedEventArgs)
        Try
            Dim socialnocolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
            x1.Fill = New System.Windows.Media.SolidColorBrush(socialnocolor)
            x2.Fill = New System.Windows.Media.SolidColorBrush(socialnocolor)
            x3.Fill = New System.Windows.Media.SolidColorBrush(socialnocolor)
            x4.Fill = New System.Windows.Media.SolidColorBrush(socialnocolor)
        Catch

        End Try

    End Sub
End Class
