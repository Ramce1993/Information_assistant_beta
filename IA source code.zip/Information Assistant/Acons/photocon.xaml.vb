﻿Public Class photocon
    Private Sub UserControl_Loaded(sender As Object, e As RoutedEventArgs)
        Try
            Dim psccolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)

            ps.Foreground = New System.Windows.Media.SolidColorBrush(psccolor)
        Catch

        End Try
    End Sub
End Class
