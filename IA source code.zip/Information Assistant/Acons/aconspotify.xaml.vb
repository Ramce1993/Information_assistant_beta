﻿Public Class aconspotify

    Private Sub UserControl_Loaded(sender As Object, e As RoutedEventArgs)
        Try
            Dim callnocolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
            elipsespot.Stroke = New System.Windows.Media.SolidColorBrush(callnocolor)
            spot1.Stroke = New System.Windows.Media.SolidColorBrush(callnocolor)
            spot2.Stroke = New System.Windows.Media.SolidColorBrush(callnocolor)
            spot3.Stroke = New System.Windows.Media.SolidColorBrush(callnocolor)
        Catch

        End Try

    End Sub
End Class
