﻿Public Class internetcontrol
    Private Sub UserControl_Loaded(sender As Object, e As RoutedEventArgs)

    End Sub
End Class
