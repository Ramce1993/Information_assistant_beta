﻿Public Class youtubeicon

    Private Sub UserControl_Loaded_1(sender As Object, e As RoutedEventArgs)
        Try
            Dim yticcolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
            Dim ytibackccolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.backcolor), Color)

            xback.Fill = New System.Windows.Media.SolidColorBrush(yticcolor)
            playicon.Fill = New System.Windows.Media.SolidColorBrush(ytibackccolor)
        Catch

        End Try
    End Sub
End Class
