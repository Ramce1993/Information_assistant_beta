﻿Public Class valutacon

    Private Sub UserControl_Loaded_2(sender As Object, e As RoutedEventArgs)
        Try
            Dim valutacolors As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
            valutalabl.Foreground = New System.Windows.Media.SolidColorBrush(valutacolors)

        Catch

        End Try
    End Sub
End Class
