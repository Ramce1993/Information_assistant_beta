﻿Public Class settingsx
    Private Sub UserControl_Loaded(sender As Object, e As RoutedEventArgs)
        Try
            Dim setsnocolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
            Dim setscolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.backcolor), Color)
            xback.Fill = New System.Windows.Media.SolidColorBrush(setsnocolor)
            xfront.Fill = New System.Windows.Media.SolidColorBrush(setscolor)
        Catch

        End Try
    End Sub
End Class
