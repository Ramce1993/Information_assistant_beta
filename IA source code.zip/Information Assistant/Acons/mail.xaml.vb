﻿Public Class mail
    Private Sub UserControl_Loaded(sender As Object, e As RoutedEventArgs)
        Try
            Dim mailcolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
            m1.Stroke = New System.Windows.Media.SolidColorBrush(mailcolor)
            m2.Stroke = New System.Windows.Media.SolidColorBrush(mailcolor)
        Catch

        End Try
    End Sub
End Class
