﻿Public Class mesocial
    Private Sub UserControl_Loaded(sender As Object, e As RoutedEventArgs)
        Try
            Dim socialnocolor As Color = CType(ColorConverter.ConvertFromString(My.Settings.mecolor), Color)
            label.Foreground = New System.Windows.Media.SolidColorBrush(socialnocolor)
            label_Copy.Foreground = New System.Windows.Media.SolidColorBrush(socialnocolor)
        Catch

        End Try

    End Sub
End Class
